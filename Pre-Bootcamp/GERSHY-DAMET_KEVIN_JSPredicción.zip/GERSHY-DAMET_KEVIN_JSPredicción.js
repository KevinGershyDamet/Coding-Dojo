//Pregunta 1: Indicará "Nací en 1980"

//Pregunta 2: Indicará "Nací en 1980"

//Pregunta 3: La consola mostrará 4 líneas: "¡Sumando números! - num1 is 10 - num2 is 20 - 30"
