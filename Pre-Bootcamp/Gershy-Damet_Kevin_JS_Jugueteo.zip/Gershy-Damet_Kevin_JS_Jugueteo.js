var alturaNiño = 120

function muestraSiElNiñoPuedeSubirALaMontañaRusa(num)
{
    if num>52 {
        console.log("¡Súbete, chico!");
    }
    else {
        console.log("Lo siento, chico. Tal vez el próximo año");
    }
}


muestraSiElNiñoPuedeSubirALaMontañaRusa(alturaNiño);