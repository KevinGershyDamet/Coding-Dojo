from flask import Flask, render_template, redirect, request
# importar la clase de friend.py

from usuario import Usuario
app = Flask(__name__)

@app.route("/")
def index():
    users = Usuario.get_all()
    print(users)
    return render_template("index.html", users = users)

@app.route('/crear')
def crear():
    return render_template('crear.html')

@app.route('/procesar', methods = ['post'])
def procesar():
    datos_nuevos = {'nombre': request.form['nombre'],
                    'ocupación': request.form['ocupación']
                    }
    Usuario.save(datos_nuevos)
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)
